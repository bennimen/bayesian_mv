Formulas for conjugate prior distributions
==========================================

.. toctree::
   :maxdepth: 2

   formulas_conjugate_general
   formulas_conjugate_beta
   formulas_conjugate_gamma
   formulas_conjugate_normal_inverse_gamma
   formulas_conjugate_pareto