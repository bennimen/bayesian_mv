Conjugate prior distributions
"""""""""""""""""""""""""""""

List of conjugate prior distributions to be used depending on the sampling
distribution.

.. toctree::
   :maxdepth: 2

   conjugate_beta
   conjugate_gamma
   conjugate_normal_inverse_gamma
   conjugate_pareto
