Base classes and utility functions
==================================

Base classes
------------

.. automodule:: cprior.cdist.base
   :members:
   :show-inheritance:


Utility functions
-----------------

.. automodule:: cprior.cdist.utils
   :members:
   :show-inheritance: